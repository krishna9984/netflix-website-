This project aims to perform an exploratory data analysis (EDA) on the Netflix Titles Dataset, which contains metadata about TV Shows and Movies available on the Netflix platform. The dataset includes various features like title, director, cast, country, date added, release year, rating, genre, and description.

By cleaning and analyzing this dataset using Python libraries such as Pandas, Matplotlib, Seaborn, and WordCloud, we extract meaningful insights about Netflix's content offerings, genre popularity, trends in releases, and frequent collaborations with actors or directors.
